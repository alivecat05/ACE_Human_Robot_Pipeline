# R-Ego Data Processing Service

## Requirements

```
Ubuntu: 22.04
python: 3.11.7
textual: 6.8.0
opencv-python: 4.12.0.88
numpy: 1.26.4
```

Other equivalent environments should also work.

## Usage

```bash
python r-ego-tui.py --input <path to your recording> --device-id <your device id> --ip <api ip>
```

The `<path to your recording>` should be the folder that contains `mjpeg.bin`, `imu.csv`, and `metadata.json`.

One recording at a time. You should expect processing time to be 20-25x recording length. It is recommended to avoid uploading videos longer than 5 min. If you need to process longer sequences, I will provide a slicing function in future release.

If you need to process multiple sequences at the same time. You can open up multiple terminals and run the command for each data sequence.

Right now, the processing capacity is 1 gpu, meaning one job at a time. If you need more, please contact us for expanding the capacity.

## To ACE

The `<your device id>` are one of the two strings: `0001` and `0002`. `0001` is the one that was brought to Shanghai by Liang Pan. `0002` is the one sent to Shenzhen later.

Your `<api ip>` is `54.245.38.108`.

## Example

```bash
python r-ego-tui.py --input /path/to/your/data --device-id 0001 --ip 54.245.38.108
```
