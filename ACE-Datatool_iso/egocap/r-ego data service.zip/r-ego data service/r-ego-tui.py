#!/usr/bin/env python3
"""
Textual UI wrapper around the api_example.sh pipeline.

Features:
- Takes an input folder containing the data to process.
- Shows the working folder and live status: preprocessing (zipping), upload,
  remote processing, and download.

Usage:
  python api_textual_ui.py --input ./sample_data/20251201_201818
  python api_textual_ui.py --input ./path --ip 35.87.146.75

Requires:
- textual (pip install textual)
- requests (pip install requests)
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict

import requests
from textual import events
from textual.app import App, ComposeResult
from textual.containers import Vertical
from textual.widgets import Footer, Header, Static, DataTable

from src.parse_databag import process_one_recording
import shutil
import zipfile

API_PORT = 8000


def preprocess_file(src: Path, device_id: str = "0001") -> Path:
    preprocessed_dir = src / "preprocessed"
    os.makedirs(preprocessed_dir, exist_ok=True)
    # shutil.copy(src.parent / "metadata.json", preprocessed_dir / "metadata.json")
    with open(preprocessed_dir / "metadata.json", 'w') as f:
        json.dump({"DEVICE UID": device_id, "DEVICE VERSION": "v1"}, f)
    process_one_recording(src, preprocessed_dir, write_video=True, imu_file_name="imu.csv")
    # zip src.parent / "preprocessed" to src.parent / "preprocessed.zip"
    with zipfile.ZipFile(src / "preprocessed.zip", 'w') as zipf:
        for file in os.listdir(preprocessed_dir):
            zipf.write(preprocessed_dir / file, file)

    return src / "preprocessed.zip"


class PipelineError(Exception):
    """Raised when the remote pipeline fails."""


class PipelineRunner:
    """Encapsulates the HTTP workflow from api_example.sh."""

    def __init__(self, ip: str, input_dir: Path, device_id: str, log_fn):
        self.ip = ip
        self.base_url = f"http://{ip}:{API_PORT}"
        self.input_dir = input_dir
        self.device_id = device_id
        self.log = log_fn

    async def _http_post(self, url: str, **kwargs) -> requests.Response:
        return await asyncio.to_thread(requests.post, url, timeout=60, **kwargs)

    async def _http_put(self, url: str, **kwargs) -> requests.Response:
        return await asyncio.to_thread(requests.put, url, timeout=300, **kwargs)

    async def _http_get(self, url: str, **kwargs) -> requests.Response:
        return await asyncio.to_thread(requests.get, url, timeout=60, **kwargs)

    async def run(self):
        overall_start = time.monotonic()

        # Preprocess (zip) local folder
        self.log("preprocessing file locally...")
        t0 = time.monotonic()
        zip_path = await asyncio.to_thread(preprocess_file, self.input_dir, self.device_id)
        self.log(f"preprocessing done in {time.monotonic() - t0:.2f}s -> {zip_path}")

        # Create job
        self.log("creating job...")
        t0 = time.monotonic()
        resp = await self._http_post(f"{self.base_url}/jobs")
        resp.raise_for_status()
        data = resp.json()
        upload_url = data["upload_url"]
        upload_key = data["upload_key"]
        job_id = data["job_id"]
        self.log(f"job created in {time.monotonic() - t0:.2f}s (id: {job_id})")

        # Upload input
        self.log("uploading input...")
        t0 = time.monotonic()
        with open(zip_path, "rb") as f:
            put_resp = await self._http_put(upload_url, data=f)
            put_resp.raise_for_status()
        self.log(f"upload done in {time.monotonic() - t0:.2f}s")

        # Start job
        self.log("starting remote processing...")
        t0 = time.monotonic()
        start_resp = await self._http_post(
            f"{self.base_url}/jobs/{job_id}/start",
            headers={"Content-Type": "application/json"},
            data=json.dumps({"input_key": upload_key}),
        )
        start_resp.raise_for_status()
        self.log(f"start request done in {time.monotonic() - t0:.2f}s")

        # Poll status
        self.log("remote processing (polling)...")
        t0 = time.monotonic()
        last_status = None
        while True:
            poll_resp = await self._http_get(f"{self.base_url}/jobs/{job_id}")
            poll_resp.raise_for_status()
            status_data: Dict[str, Any] = poll_resp.json()
            status = status_data.get("status")
            if status != last_status:
                if status == "QUEUED":
                    self.log("remote processing status: QUEUED (waiting for worker)")
                elif status == "RUNNING":
                    self.log("remote processing status: RUNNING")
                else:
                    self.log(f"remote processing status: {status}")
                last_status = status
            if status == "SUCCEEDED":
                download_url = status_data.get("download_url")
                result_key = status_data.get("result_key")
                self.log(f"job succeeded, result key: {result_key}")
                self.log(
                    f"remote processing finished in {time.monotonic() - t0:.2f}s"
                )
                break
            if status == "FAILED":
                message = status_data.get("message", "Unknown error")
                raise PipelineError(message)
            await asyncio.sleep(10)

        # Download result
        self.log("downloading result...")
        t0 = time.monotonic()
        out_path = self.input_dir / "output.zip"
        dl_resp = await self._http_get(download_url, stream=True)
        dl_resp.raise_for_status()
        with open(out_path, "wb") as f:
            for chunk in dl_resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)

        self.log(f"downloaded in {time.monotonic() - t0:.2f}s -> {out_path}")
        self.log(f"total time {time.monotonic() - overall_start:.2f}s")


class PipelineApp(App):
    """Textual application that shows pipeline status."""

    TITLE = "R-Ego Data Processing Service"

    CSS = """
    Screen {
      layout: vertical;
    }
    #title {
      padding: 1 2;
      content-align: center middle;
      text-style: bold;
    }
    #working {
      padding: 1 2;
      text-style: bold;
    }
    #status {
      padding: 1 2;
      text-style: bold;
    }
    #log {
      height: 1fr;
      border: heavy $surface-darken-2;
    }
    """

    BINDINGS = [("q", "quit", "Quit")]

    def __init__(self, ip: str, input_dir: Path, device_id: str):
        super().__init__()
        self.ip = ip
        self.input_dir = input_dir
        self.device_id = device_id
        self.status_widget: Static | None = None
        self.log_widget: DataTable | None = None
        self._log_counter = 0

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static(
            "R-Ego Data Processing Service", id="title"
        )
        yield Static(
            f"Working folder: {self.input_dir.resolve()} | Device: {self.device_id}",
            id="working",
        )
        self.status_widget = Static("Status: initializing", id="status")
        self.log_widget = DataTable(id="log", zebra_stripes=True, show_cursor=False)
        self.log_widget.add_columns("#", "Message")
        yield Vertical(self.status_widget, self.log_widget)
        yield Footer()

    async def on_mount(self) -> None:
        asyncio.create_task(self.run_pipeline())

    def ui_log(self, message: str) -> None:
        if self.log_widget:
            self._log_counter += 1
            self.log_widget.add_row(str(self._log_counter), message)
            self.log_widget.scroll_end(animate=False)
        if self.status_widget:
            self.status_widget.update(f"Status: {message}")

    async def run_pipeline(self):
        runner = PipelineRunner(self.ip, self.input_dir, self.device_id, self.ui_log)
        try:
            await runner.run()
            self.ui_log("pipeline complete")
        except PipelineError as e:
            self.ui_log(f"remote processing failed: {e}")
        except requests.HTTPError as e:
            self.ui_log(f"http error: {e}")
        except Exception as e:  # pragma: no cover - safeguard
            self.ui_log(f"unexpected error: {e}")

    async def on_key(self, event: events.Key) -> None:
        if event.key == "ctrl+c":
            await self.action_quit()


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Textual UI for API pipeline")
    parser.add_argument(
        "--input",
        required=True,
        help="Input folder containing data to process",
    )
    parser.add_argument(
        "--device-id",
        required=True,
        help="Device ID",
    )
    parser.add_argument(
        "--ip",
        required=True,
        help="API server IP",
    )
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    input_dir = Path(args.input).expanduser().resolve()
    if not input_dir.is_dir():
        print(f"Input folder not found: {input_dir}", file=sys.stderr)
        return 1

    app = PipelineApp(args.ip, input_dir, args.device_id)
    app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

