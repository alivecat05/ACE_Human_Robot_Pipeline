#!/bin/bash
# Installation script for egocap

set -e

INSTALL_DIR="${1:-/opt/egocap}"
BIN_DIR="/usr/local/bin"

echo "Installing egocap to $INSTALL_DIR..."

# Create installation directory
sudo mkdir -p "$INSTALL_DIR/bin"

# Copy files
sudo cp -r bin/* "$INSTALL_DIR/bin/"

# Create symlink
sudo ln -sf "$INSTALL_DIR/bin/egocap" "$BIN_DIR/egocap"
sudo ln -sf "$INSTALL_DIR/bin/parse_databag.py" "$BIN_DIR/parse_databag.py"

# Check for libusb-1.0
if ! ldconfig -p | grep -q libusb-1.0; then
    echo ""
    echo "WARNING: libusb-1.0 not found in system library path."
    echo "Please install it with:"
    echo "  Ubuntu/Debian: sudo apt install libusb-1.0-0"
    echo "  CentOS/RHEL:   sudo yum install libusb"
    echo ""
fi

echo "Installation complete!"
echo "Run 'egocap --help' to get started."
