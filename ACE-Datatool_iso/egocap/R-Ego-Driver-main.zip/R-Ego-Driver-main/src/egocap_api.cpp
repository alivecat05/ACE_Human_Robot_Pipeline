#include "egocap_api.hpp"
#include "seeker.hpp"
#include <atomic>
#include <csignal>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <cstring>

namespace egocap {

// Internal implementation
class EgocapImpl {
public:
    EgocapImpl(const std::string& output_base_dir) 
        : should_exit_(false), output_base_dir_(output_base_dir), 
          imu_callback_(nullptr), image_callback_(nullptr), user_data_(nullptr),
          is_running_(false), error_msg_("") {
        // Don't set signal handlers here - let customer handle signals
        // Customer can call egocap_stop() from their signal handler
    }

    ~EgocapImpl() {
        stop();
    }

    int start() {
        if (is_running_) {
            error_msg_ = "Already running";
            return 1;
        }

        if (!prepareOutput()) {
            error_msg_ = "Failed to prepare output directory/files";
            return 2;
        }

        // Discover and open device
        std::vector<seeker_device_t> devices = seeker_.find_devices();
        if (devices.empty()) {
            error_msg_ = "No R-Ego Devices Found";
            return 1;
        }
        
        if (seeker_.open(devices[0]) != 0) {
            error_msg_ = "Failed to open device";
            return 1;
        }

        // Query device info
        seeker_.get_dev_info(device_info_);
        writeDeviceMetadata(devices[0]);

        // Register callbacks
        seeker_.set_event_callback([this](auto &hdr, auto &evt) { onEvent(hdr, evt); });
        seeker_.set_mjpeg_callback([this](auto &hdr, auto data, int len) { onMjpeg(hdr, data, len); });
        seeker_.set_timer_callback([this](auto &tg, auto &ts) { return onTimer(tg, ts); });

        // Start streams
        seeker_.start_event_stream();
        seeker_.start_image_stream();
        seeker_.start_depth_stream();

        is_running_ = true;
        return 0;
    }

    void stop() {
        if (!is_running_) return;
        
        should_exit_.store(true);
        is_running_ = false;
        seeker_.stop_event_stream();
        seeker_.stop_image_stream();
        seeker_.stop_depth_stream();
        seeker_.close();
        closeOutput();
    }

    bool isRunning() const { return is_running_; }

    void setImuCallback(ImuCallback cb, void* user_data) {
        imu_callback_ = cb;
        user_data_ = user_data;
    }

    void setImageCallback(ImageCallback cb, void* user_data) {
        image_callback_ = cb;
        user_data_ = user_data;
    }

    const char* getError() const { return error_msg_.c_str(); }

    void run() {
        while (is_running_ && !should_exit_.load()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        if (should_exit_.load()) {
            stop();
        }
    }

private:

    void onEvent(event_header_t &header, device_event_t &event) {
        if (event.type == EVENT_TYPE_SENSOR_CUSTOM && imu_callback_) {
            const uint64_t device_ts_ns = header.sec * 1000000000ull + header.nsec;
            const uint64_t host_ts_ns = getHostTimestamp();
            
            ImuData data;
            data.device_timestamp_ns = device_ts_ns;
            data.host_timestamp_ns = host_ts_ns;
            data.gyro_x = event.event.sensor_custom.angular_velocity_x;
            data.gyro_y = event.event.sensor_custom.angular_velocity_y;
            data.gyro_z = event.event.sensor_custom.angular_velocity_z;
            data.acc_x = event.event.sensor_custom.linear_acceleration_x;
            data.acc_y = event.event.sensor_custom.linear_acceleration_y;
            data.acc_z = event.event.sensor_custom.linear_acceleration_z;
            
            imu_callback_(&data, user_data_);
            
            // Also write to file
            writeImu(device_ts_ns, host_ts_ns,
                     data.gyro_x, data.gyro_y, data.gyro_z,
                     data.acc_x, data.acc_y, data.acc_z);
        }
    }

    void onMjpeg(event_header_t &pheader, const uint8_t *data, int len) {
        const uint64_t device_ts_ns = pheader.sec * 1000000000ull + pheader.nsec;
        const uint64_t host_ts_ns = getHostTimestamp();
        
        if (image_callback_) {
            ImageData img_data;
            img_data.device_timestamp_ns = device_ts_ns;
            img_data.host_timestamp_ns = host_ts_ns;
            img_data.jpeg_data = data;
            img_data.jpeg_size = len;
            image_callback_(&img_data, user_data_);
        }
        
        // Also write to file
        writeJpeg(device_ts_ns, host_ts_ns, data, len);
    }

    bool onTimer(std::pair<uint64_t, uint64_t> &timer_get, std::pair<uint64_t, uint64_t> &timer_set) {
        using namespace std::chrono;
        const auto now = steady_clock::now().time_since_epoch();
        const uint64_t ns = duration_cast<nanoseconds>(now).count();
        timer_set.first = ns / 1000000000ull;
        timer_set.second = ns % 1000000000ull;
        (void)timer_get;
        return true;
    }

    uint64_t getHostTimestamp() {
        using namespace std::chrono;
        const auto now = system_clock::now().time_since_epoch();
        return duration_cast<nanoseconds>(now).count();
    }

    void writeDeviceMetadata(const seeker_device_t& dev) {
        std::string host_mac = getHostMacAddress();
        std::string seeker_mac = getSeekerDeviceMacAddress(dev);
        
        uint64_t host_uid = hashMacTo10Digits(host_mac);
        uint64_t seeker_uid = hashMacTo10Digits(seeker_mac);
        
        std::ofstream json_out(output_dir_ + "/metadata.json");
        if (!json_out.is_open()) return;
        
        json_out << "{\n";
        json_out << "  \"host\": {\n";
        json_out << "    \"version\": \"1.0.0\",\n";
        json_out << "    \"uid\": \"" << std::setfill('0') << std::setw(10) << host_uid << "\"\n";
        json_out << "  },\n";
        json_out << "  \"r-ego_device\": {\n";
        json_out << "    \"version\": \"1.0.0\",\n";
        json_out << "    \"uid\": \"" << std::setfill('0') << std::setw(10) << seeker_uid << "\"\n";
        json_out << "  }\n";
        json_out << "}\n";
        json_out.close();
    }

    std::string getHostMacAddress() {
        std::vector<std::string> interfaces = {"eth0", "enp0s3", "enp0s8"};
        for (const auto& ifname : interfaces) {
            std::string path = "/sys/class/net/" + ifname + "/address";
            std::ifstream file(path);
            if (file.is_open()) {
                std::string mac;
                std::getline(file, mac);
                file.close();
                if (!mac.empty() && mac.length() >= 17) {
                    return mac;
                }
            }
        }
        return "";
    }

    std::string getSeekerDeviceMacAddress(const seeker_device_t& dev) {
        std::ostringstream oss;
        oss << dev.devnum;
        return oss.str();
    }

    uint64_t hashMacTo10Digits(const std::string& mac) {
        std::hash<std::string> hasher;
        size_t hash_value = hasher(mac);
        return static_cast<uint64_t>(hash_value) % 10000000000ULL;
    }

    bool prepareOutput() {
        const auto now = std::chrono::system_clock::now();
        std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tm{};
#if defined(_WIN32)
        localtime_s(&tm, &t);
#else
        localtime_r(&t, &tm);
#endif
        char buf[32];
        std::strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", &tm);
        
        std::string base_dir = output_base_dir_.empty() ? "recordings" : output_base_dir_;
        output_dir_ = base_dir + "/" + buf;
        
        std::error_code ec;
        std::filesystem::create_directories(output_dir_, ec);
        if (ec) return false;
        
        mjpeg_out_.open(output_dir_ + "/mjpeg.bin", std::ios::binary);
        imu_out_.open(output_dir_ + "/imu.csv", std::ios::out);
        if (!mjpeg_out_.is_open() || !imu_out_.is_open()) return false;
        
        imu_out_ << "device_timestamp_ns,host_timestamp_ns,gyro_x,gyro_y,gyro_z,acc_x,acc_y,acc_z\n";
        const char magic[] = {'R','O','B','A','T','A',2,0,0,0};
        mjpeg_out_.write(magic, sizeof(magic));
        return true;
    }

    void closeOutput() {
        std::scoped_lock<std::mutex> lk(out_mutex_);
        if (mjpeg_out_.is_open()) mjpeg_out_.flush();
        if (imu_out_.is_open()) imu_out_.flush();
        if (mjpeg_out_.is_open()) mjpeg_out_.close();
        if (imu_out_.is_open()) imu_out_.close();
    }

    void writeJpeg(uint64_t device_ts_ns, uint64_t host_ts_ns, const uint8_t *data, int len) {
        std::scoped_lock<std::mutex> lk(out_mutex_);
        if (!mjpeg_out_.is_open() || data == nullptr || len <= 0) return;
        uint64_t device_ts = device_ts_ns;
        uint64_t host_ts = host_ts_ns;
        uint32_t sz = static_cast<uint32_t>(len);
        mjpeg_out_.write(reinterpret_cast<const char*>(&device_ts), sizeof(device_ts));
        mjpeg_out_.write(reinterpret_cast<const char*>(&host_ts), sizeof(host_ts));
        mjpeg_out_.write(reinterpret_cast<const char*>(&sz), sizeof(sz));
        mjpeg_out_.write(reinterpret_cast<const char*>(data), sz);
    }

    void writeImu(uint64_t device_ts_ns, uint64_t host_ts_ns,
                  double gx, double gy, double gz,
                  double ax, double ay, double az) {
        std::scoped_lock<std::mutex> lk(out_mutex_);
        if (!imu_out_.is_open()) return;
        imu_out_ << device_ts_ns << "," << host_ts_ns << ","
                 << std::setprecision(9) << gx << "," << gy << "," << gz << ","
                 << ax << "," << ay << "," << az << "\n";
    }

    SEEKNS::SEEKER seeker_;
    seeker_device_t device_info_{};
    std::atomic<bool> should_exit_;
    std::atomic<bool> is_running_;
    std::string output_dir_;
    std::string output_base_dir_;
    std::ofstream mjpeg_out_;
    std::ofstream imu_out_;
    std::mutex out_mutex_;
    std::string error_msg_;

    ImuCallback imu_callback_;
    ImageCallback image_callback_;
    void* user_data_;
};

// C API implementation
struct EgocapHandle {
    EgocapImpl* impl;
};

} // namespace egocap

// C API exports
extern "C" {

egocap::EgocapHandle* egocap_create(const char* output_dir) {
    try {
        egocap::EgocapHandle* handle = new egocap::EgocapHandle;
        handle->impl = new egocap::EgocapImpl(output_dir ? output_dir : "");
        return handle;
    } catch (...) {
        return nullptr;
    }
}

void egocap_destroy(egocap::EgocapHandle* handle) {
    if (handle) {
        delete handle->impl;
        delete handle;
    }
}

void egocap_set_imu_callback(egocap::EgocapHandle* handle, egocap::ImuCallback callback, void* user_data) {
    if (handle && handle->impl) {
        handle->impl->setImuCallback(callback, user_data);
    }
}

void egocap_set_image_callback(egocap::EgocapHandle* handle, egocap::ImageCallback callback, void* user_data) {
    if (handle && handle->impl) {
        handle->impl->setImageCallback(callback, user_data);
    }
}

int egocap_start(egocap::EgocapHandle* handle) {
    if (!handle || !handle->impl) return -1;
    return handle->impl->start();
}

void egocap_stop(egocap::EgocapHandle* handle) {
    if (handle && handle->impl) {
        handle->impl->stop();
    }
}

bool egocap_is_running(egocap::EgocapHandle* handle) {
    if (!handle || !handle->impl) return false;
    return handle->impl->isRunning();
}

const char* egocap_get_error(egocap::EgocapHandle* handle) {
    if (!handle || !handle->impl) return "Invalid handle";
    return handle->impl->getError();
}

} // extern "C"

