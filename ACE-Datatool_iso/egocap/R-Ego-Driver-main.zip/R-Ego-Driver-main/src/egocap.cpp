#include "seeker.hpp"
#include <atomic>
#include <csignal>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <cstring>

class EgocapApp {
public:
    EgocapApp(const std::string& output_base_dir = "") : should_exit_(false), output_base_dir_(output_base_dir) {
        std::signal(SIGINT, &EgocapApp::handleSignal);
        std::signal(SIGTERM, &EgocapApp::handleSignal);
    }

    int run() {
        if (!prepareOutput()) {
            std::cerr << "Failed to prepare output directory/files" << std::endl;
            return 2;
        }
        // Discover and open device
        std::vector<seeker_device_t> devices = seeker_.find_devices();
        if (devices.empty()) {
            std::cerr << "No R-Ego Devices Found" << std::endl;
            return 1;
        }
        seeker_.open(devices[0]);

        // Query device info
        seeker_.get_dev_info(device_info_);
        printDevice(devices[0]);
        writeDeviceMetadata(devices[0]);

        // Register callbacks
        seeker_.set_event_callback([this](auto &hdr, auto &evt) { onEvent(hdr, evt); });
        seeker_.set_mjpeg_callback([this](auto &hdr, auto data, int len) { onMjpeg(hdr, data, len); });
        seeker_.set_timer_callback([this](auto &tg, auto &ts) { return onTimer(tg, ts); });

        // Start streams
        seeker_.start_event_stream();
        seeker_.start_image_stream();
        seeker_.start_depth_stream();

        // Main loop
        while (!global_exit_flag().load()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }

        // Cleanup
        seeker_.stop_event_stream();
        seeker_.stop_image_stream();
        seeker_.stop_depth_stream();
        seeker_.close();
        closeOutput();
        return 0;
    }

private:
    static void handleSignal(int) { global_exit_flag().store(true); }
    static std::atomic<bool> &global_exit_flag() { static std::atomic<bool> f{false}; return f; }

    void onEvent(event_header_t &header, device_event_t &event) {
        if (event.type == EVENT_TYPE_SENSOR_CUSTOM) {
            const uint64_t device_ts_ns = header.sec * 1000000000ull + header.nsec;
            const uint64_t host_ts_ns = getHostTimestamp();
            writeImu(device_ts_ns, host_ts_ns,
                     event.event.sensor_custom.angular_velocity_x,
                     event.event.sensor_custom.angular_velocity_y,
                     event.event.sensor_custom.angular_velocity_z,
                     event.event.sensor_custom.linear_acceleration_x,
                     event.event.sensor_custom.linear_acceleration_y,
                     event.event.sensor_custom.linear_acceleration_z);
        }
    }

    void onMjpeg(event_header_t &pheader, const uint8_t *data, int len) {
        const uint64_t device_ts_ns = pheader.sec * 1000000000ull + pheader.nsec;
        const uint64_t host_ts_ns = getHostTimestamp();
        writeJpeg(device_ts_ns, host_ts_ns, data, len);
    }

    bool onTimer(std::pair<uint64_t, uint64_t> &timer_get, std::pair<uint64_t, uint64_t> &timer_set) {
        using namespace std::chrono;
        const auto now = steady_clock::now().time_since_epoch();
        const uint64_t ns = duration_cast<nanoseconds>(now).count();
        timer_set.first = ns / 1000000000ull;
        timer_set.second = ns % 1000000000ull;
        (void)timer_get;
        return true;
    }

    uint64_t getHostTimestamp() {
        using namespace std::chrono;
        const auto now = system_clock::now().time_since_epoch();
        return duration_cast<nanoseconds>(now).count();
    }

    void printDevice(const seeker_device_t &dev) {
        std::cout << dev << std::endl;
        std::cout << "RGB cameras: " << (int)device_info_.dev_info.rgb_camera_number
                  << "  size: " << device_info_.dev_info.rgb_resolution_width
                  << "x" << device_info_.dev_info.rgb_resolution_height << std::endl;
        std::cout << "Depth cameras: " << (int)device_info_.dev_info.depth_camera_number
                  << "  size: " << device_info_.dev_info.depth_resolution_width
                  << "x" << device_info_.dev_info.depth_resolution_height << std::endl;
    }

    std::string getHostMacAddress() {
        // Read MAC address from eth0 (primary Ethernet interface on Raspberry Pi/Radxa Pi)
        std::vector<std::string> interfaces = {"eth0", "enp0s3", "enp0s8"};
        for (const auto& ifname : interfaces) {
            std::string path = "/sys/class/net/" + ifname + "/address";
            std::ifstream file(path);
            if (file.is_open()) {
                std::string mac;
                std::getline(file, mac);
                file.close();
                if (!mac.empty() && mac.length() >= 17) {
                    return mac;
                }
            }
        }
        return ""; // Return empty if not found
    }

    std::string getSeekerDeviceMacAddress(const seeker_device_t& dev) {
        // USB devices don't have MAC addresses, use devnum as unique hardware identifier
        // devnum is hardware-bound and remains unchanged
        std::ostringstream oss;
        oss << dev.devnum;
        return oss.str();
    }

    uint64_t hashMacTo10Digits(const std::string& mac) {
        std::hash<std::string> hasher;
        size_t hash_value = hasher(mac);
        // Convert to 10-digit number (modulo 10000000000)
        return static_cast<uint64_t>(hash_value) % 10000000000ULL;
    }

    void writeDeviceMetadata(const seeker_device_t& dev) {
        std::string host_mac = getHostMacAddress();
        std::string seeker_mac = getSeekerDeviceMacAddress(dev);
        
        uint64_t host_uid = hashMacTo10Digits(host_mac);
        uint64_t seeker_uid = hashMacTo10Digits(seeker_mac);
        
        std::ofstream json_out(output_dir_ + "/metadata.json");
        if (!json_out.is_open()) {
            std::cerr << "Warning: Failed to create device_metadata.json" << std::endl;
            return;
        }
        
        json_out << "{\n";
        json_out << "  \"host\": {\n";
        json_out << "    \"version\": \"1.0.0\",\n";
        json_out << "    \"uid\": \"" << std::setfill('0') << std::setw(10) << host_uid << "\"\n";
        json_out << "  },\n";
        json_out << "  \"r-ego_device\": {\n";
        json_out << "    \"version\": \"1.0.0\",\n";
        json_out << "    \"uid\": \"" << std::setfill('0') << std::setw(10) << seeker_uid << "\"\n";
        json_out << "  }\n";
        json_out << "}\n";
        json_out.close();
    }

private:
    SEEKNS::SEEKER seeker_;
    seeker_device_t device_info_{};
    std::atomic<bool> should_exit_;
    // output
    std::ofstream mjpeg_out_;
    std::ofstream imu_out_;
    std::mutex out_mutex_;
    std::string output_dir_;
    std::string output_base_dir_;

    bool prepareOutput() {
        const auto now = std::chrono::system_clock::now();
        std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tm{};
#if defined(_WIN32)
        localtime_s(&tm, &t);
#else
        localtime_r(&t, &tm);
#endif
        char buf[32];
        std::strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", &tm);
        
        // Use provided base directory or default to "recordings"
        std::string base_dir = output_base_dir_.empty() ? "recordings" : output_base_dir_;
        output_dir_ = base_dir + "/" + buf;
        
        std::error_code ec;
        std::filesystem::create_directories(output_dir_, ec);
        if (ec) return false;
        mjpeg_out_.open(output_dir_ + "/mjpeg.bin", std::ios::binary);
        imu_out_.open(output_dir_ + "/imu.csv", std::ios::out);
        if (!mjpeg_out_.is_open() || !imu_out_.is_open()) return false;
        imu_out_ << "device_timestamp_ns,host_timestamp_ns,gyro_x,gyro_y,gyro_z,acc_x,acc_y,acc_z\n";
        const char magic[] = {'R','O','B','A','T','A',2,0,0,0}; // Version 2 for dual timestamps
        mjpeg_out_.write(magic, sizeof(magic));
        return true;
    }

    void closeOutput() {
        std::scoped_lock<std::mutex> lk(out_mutex_);
        if (mjpeg_out_.is_open()) mjpeg_out_.flush();
        if (imu_out_.is_open()) imu_out_.flush();
        if (mjpeg_out_.is_open()) mjpeg_out_.close();
        if (imu_out_.is_open()) imu_out_.close();
        std::cout << "Saved recordings to: " << output_dir_ << std::endl;
    }

    void writeJpeg(uint64_t device_ts_ns, uint64_t host_ts_ns, const uint8_t *data, int len) {
        std::scoped_lock<std::mutex> lk(out_mutex_);
        if (!mjpeg_out_.is_open() || data == nullptr || len <= 0) return;
        uint64_t device_ts = device_ts_ns;
        uint64_t host_ts = host_ts_ns;
        uint32_t sz = static_cast<uint32_t>(len);
        mjpeg_out_.write(reinterpret_cast<const char*>(&device_ts), sizeof(device_ts));
        mjpeg_out_.write(reinterpret_cast<const char*>(&host_ts), sizeof(host_ts));
        mjpeg_out_.write(reinterpret_cast<const char*>(&sz), sizeof(sz));
        mjpeg_out_.write(reinterpret_cast<const char*>(data), sz);
    }

    void writeImu(uint64_t device_ts_ns, uint64_t host_ts_ns,
                  double gx, double gy, double gz,
                  double ax, double ay, double az) {
        std::scoped_lock<std::mutex> lk(out_mutex_);
        if (!imu_out_.is_open()) return;
        imu_out_ << device_ts_ns << "," << host_ts_ns << ","
                 << std::setprecision(9) << gx << "," << gy << "," << gz << ","
                 << ax << "," << ay << "," << az << "\n";
    }
};

int main(int argc, char* argv[]) {
    std::string output_dir;
    
    // Parse command-line arguments
    if (argc > 1) {
        if (argc == 2 && (std::strcmp(argv[1], "-h") == 0 || std::strcmp(argv[1], "--help") == 0)) {
            std::cout << "Usage: " << argv[0] << " [output_directory]\n"
                      << "  output_directory: Base directory for recordings (default: recordings/)\n"
                      << "                   A timestamped subdirectory will be created automatically.\n";
            return 0;
        }
        output_dir = argv[1];
    }
    
    EgocapApp app(output_dir);
    // synchronize exit flag
    return app.run();
}


