cmake_minimum_required(VERSION 3.5)
project(egocap)

include(${CMAKE_CURRENT_SOURCE_DIR}/cmake/static.cmake)