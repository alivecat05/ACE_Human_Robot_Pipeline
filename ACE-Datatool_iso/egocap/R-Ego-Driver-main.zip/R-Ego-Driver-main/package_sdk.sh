#!/bin/bash
# Package SDK for customers
# Creates libegocap.so + headers + example driver source

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_NAME="egocap"
VERSION="${1:-1.0.0}"
ARCH="${2:-$(uname -m)}"

# Determine architecture
if [[ "$ARCH" == "x86_64" ]] || [[ "$ARCH" == "amd64" ]]; then
    ARCH_DIR="x86"
    ARCH_NAME="x86_64"
elif [[ "$ARCH" == "aarch64" ]] || [[ "$ARCH" == "arm64" ]]; then
    ARCH_DIR="arm64"
    ARCH_NAME="aarch64"
else
    echo "Error: Unsupported architecture: $ARCH"
    exit 1
fi

echo "========================================="
echo "Packaging SDK v$VERSION for $ARCH_NAME"
echo "========================================="

# Build directory
BUILD_DIR="$SCRIPT_DIR/build_sdk"
PACKAGE_DIR="$SCRIPT_DIR/sdk"
SDK_NAME="${PROJECT_NAME}-sdk-${VERSION}-${ARCH_NAME}"

# Clean previous builds
echo "Cleaning previous builds..."
rm -rf "$BUILD_DIR" "$PACKAGE_DIR"

# Create build directory
mkdir -p "$BUILD_DIR"

# Configure and build library
echo "Configuring CMake for library build..."
cd "$BUILD_DIR"
cmake "$SCRIPT_DIR" \
    -DCMAKE_BUILD_TYPE=Release \
    -DEGOCAP_BUILD_LIBRARY=ON \
    -DEGOCAP_STRIP_BINARY=ON \
    -DCMAKE_INSTALL_PREFIX="$PACKAGE_DIR/$SDK_NAME"

echo "Building library..."
cmake --build . -j$(nproc)

echo "Installing SDK..."
cmake --install .

# Create SDK structure
cd "$PACKAGE_DIR/$SDK_NAME"

# Hide libseeker.so by renaming it to libegocap_dep.so
# This is done ONLY in packaging, not in CMake (CMake stays clean for customers)
mkdir -p lib

# Remove any libseeker.so that might have been installed by CMake
if [ -f "bin/libseeker.so" ]; then
    rm -f bin/libseeker.so
fi

# Copy libseeker.so with new name
if [ -f "$SCRIPT_DIR/libs/$ARCH_DIR/libseeker.so" ]; then
    cp "$SCRIPT_DIR/libs/$ARCH_DIR/libseeker.so" lib/libegocap_dep.so
    echo "Copied libseeker.so as libegocap_dep.so (hidden name)"
    
    # Use patchelf to rename the dependency in libegocap.so
    if command -v patchelf >/dev/null 2>&1; then
        echo "Renaming dependency in libegocap.so using patchelf..."
        patchelf --replace-needed libseeker.so libegocap_dep.so lib/libegocap.so
        echo "✓ Dependency renamed successfully"
        
        # Verify it worked
        if ldd lib/libegocap.so 2>/dev/null | grep -q "libegocap_dep"; then
            echo "✓ Verified: libegocap.so now references libegocap_dep.so"
        else
            echo "Warning: Verification failed, but continuing..."
        fi
    else
        echo "Error: patchelf not found!"
        echo "Install it: sudo apt install patchelf"
        echo "Cannot hide libseeker.so without patchelf"
        exit 1
    fi
else
    echo "Error: libseeker.so not found in $SCRIPT_DIR/libs/$ARCH_DIR/"
    exit 1
fi

# Copy example driver source
mkdir -p examples
if [ -f "$SCRIPT_DIR/examples/customer_driver.cpp" ]; then
    cp "$SCRIPT_DIR/examples/customer_driver.cpp" examples/
    cp "$SCRIPT_DIR/examples/CMakeLists.txt" examples/
else
    echo "Warning: examples/customer_driver.cpp not found, skipping example files"
fi

# Create README for SDK
cat > README.txt << README_EOF
========================================
egocap SDK v${VERSION}
Architecture: ${ARCH_NAME}
========================================

This SDK allows you to build your own driver application using the egocap library.

CONTENTS:
---------
- lib/libegocap.so      : egocap library (your proprietary code)
- lib/libegocap_dep.so  : Internal dependency library
- include/egocap_api.hpp: C++ API header
- examples/             : Example driver source code

BUILDING YOUR DRIVER:
---------------------
1. Copy the example driver or create your own:

   # Create your driver source (e.g., my_driver.cpp)
   # Include the API header:
   #include "egocap_api.hpp"

2. Build your driver using the provided build script:

   cd examples
   ./build.sh

   # Alternatively, you can build manually:
   mkdir build && cd build
   cmake .. -DEGOCAP_LIB_DIR=$(pwd)/../lib
   cmake --build .

3. Run your driver:

   ./build/customer_driver [output_directory]

DEPENDENCIES:
-------------
- libusb-1.0 (install via package manager)
  Ubuntu/Debian: sudo apt install libusb-1.0-0
  CentOS/RHEL:   sudo yum install libusb

API USAGE:
----------
See examples/customer_driver.cpp for complete example.

Basic usage:
1. Create instance: egocap::EgocapHandle* h = egocap::egocap_create(output_dir);
2. Set callbacks: egocap::egocap_set_imu_callback(h, callback, user_data);
3. Start: egocap::egocap_start(h);
4. Run your main loop
5. Stop: egocap::egocap_stop(h);
6. Destroy: egocap::egocap_destroy(h);

BENEFITS:
---------
✓ Compile on your platform (solves glibc compatibility)
✓ Full control over your driver logic
✓ No source code exposure of proprietary egocap implementation
✓ Simple C++ API

LICENSE:
--------
This is proprietary software. All rights reserved.
README_EOF

# Create simple build script for customers
cat > examples/build.sh << 'BUILD_EOF'
#!/bin/bash
# Simple build script for customer driver

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK_DIR="$(dirname "$SCRIPT_DIR")"

echo "Building customer driver..."

mkdir -p build
cd build

cmake .. \
    -DEGOCAP_LIB_DIR="$SDK_DIR/lib" \
    -DEGOCAP_INCLUDE_DIR="$SDK_DIR/include/egocap" \
    -DCMAKE_BUILD_TYPE=Release

cmake --build .

echo "Build complete! Binary: build/customer_driver"
echo "Run with: LD_LIBRARY_PATH=$SDK_DIR/lib ./build/customer_driver"
BUILD_EOF

chmod +x examples/build.sh

# Create tarball
cd "$PACKAGE_DIR"
echo "Creating SDK tarball..."
tar -czf "${SDK_NAME}.tar.gz" "$SDK_NAME"

# Create checksums
echo "Generating checksums..."
sha256sum "${SDK_NAME}.tar.gz" > "${SDK_NAME}.tar.gz.sha256"
md5sum "${SDK_NAME}.tar.gz" > "${SDK_NAME}.tar.gz.md5" 2>/dev/null || true

echo ""
echo "========================================="
echo "SDK package created successfully!"
echo "========================================="
echo "Location: $PACKAGE_DIR/${SDK_NAME}.tar.gz"
echo "Size: $(du -h "$PACKAGE_DIR/${SDK_NAME}.tar.gz" | cut -f1)"
echo ""
echo "Package contents:"
ls -lh "$PACKAGE_DIR/${SDK_NAME}/"
echo ""
echo "Customer can:"
echo "  1. Extract SDK"
echo "  2. Compile example driver on their platform"
echo "  3. Link against libegocap.so"
echo ""

