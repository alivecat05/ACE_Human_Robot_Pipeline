#ifndef __EGOCAP_API_HPP__
#define __EGOCAP_API_HPP__

#include <cstdint>
#include <string>

// C++ API for egocap library
// Customers compile their driver against this API and link with libegocap.so

namespace egocap {

// Forward declarations
struct EgocapHandle;
struct ImuData {
    uint64_t device_timestamp_ns;
    uint64_t host_timestamp_ns;
    double gyro_x, gyro_y, gyro_z;
    double acc_x, acc_y, acc_z;
};

struct ImageData {
    uint64_t device_timestamp_ns;
    uint64_t host_timestamp_ns;
    const uint8_t* jpeg_data;
    int jpeg_size;
};

// Callback function types
typedef void (*ImuCallback)(const ImuData* data, void* user_data);
typedef void (*ImageCallback)(const ImageData* data, void* user_data);

// API Functions

/**
 * Create an egocap instance
 * @param output_dir Output directory for recordings (empty = default "recordings/")
 * @return Handle pointer, or nullptr on error
 */
extern "C" EgocapHandle* egocap_create(const char* output_dir = nullptr);

/**
 * Destroy an egocap instance
 * @param handle Handle from egocap_create()
 */
extern "C" void egocap_destroy(EgocapHandle* handle);

/**
 * Set IMU data callback
 * @param handle Handle from egocap_create()
 * @param callback Function to call when IMU data arrives
 * @param user_data User data passed to callback
 */
extern "C" void egocap_set_imu_callback(EgocapHandle* handle, ImuCallback callback, void* user_data);

/**
 * Set image data callback
 * @param handle Handle from egocap_create()
 * @param callback Function to call when image data arrives
 * @param user_data User data passed to callback
 */
extern "C" void egocap_set_image_callback(EgocapHandle* handle, ImageCallback callback, void* user_data);

/**
 * Start recording (discovers device, opens streams)
 * @param handle Handle from egocap_create()
 * @return 0 on success, non-zero on error
 */
extern "C" int egocap_start(EgocapHandle* handle);

/**
 * Stop recording and cleanup
 * @param handle Handle from egocap_create()
 */
extern "C" void egocap_stop(EgocapHandle* handle);

/**
 * Check if recording is active
 * @param handle Handle from egocap_create()
 * @return true if active, false otherwise
 */
extern "C" bool egocap_is_running(EgocapHandle* handle);

/**
 * Get last error message
 * @param handle Handle from egocap_create()
 * @return Error message string (valid until next API call)
 */
extern "C" const char* egocap_get_error(EgocapHandle* handle);

} // namespace egocap

#endif // __EGOCAP_API_HPP__

