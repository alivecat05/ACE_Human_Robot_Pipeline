cmake_minimum_required(VERSION 3.5)
project(egocap)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Headers for your own code
include_directories(
  ${CMAKE_CURRENT_SOURCE_DIR}/include
)

# Pick correct lib dir based on architecture
if(CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|x86")
  set(LIB_DIR "${CMAKE_CURRENT_SOURCE_DIR}/libs/x86")
elseif(CMAKE_SYSTEM_PROCESSOR MATCHES "aarch64|ARM64")
  set(LIB_DIR "${CMAKE_CURRENT_SOURCE_DIR}/libs/arm64")
else()
  message(WARNING "Unknown arch ${CMAKE_SYSTEM_PROCESSOR}, defaulting to x86 libs")
  set(LIB_DIR "${CMAKE_CURRENT_SOURCE_DIR}/libs/x86")
endif()

# Just for debugging, will show where it's looking
message(STATUS "Using LIB_DIR = ${LIB_DIR}")

# Option to build as library instead of executable
option(EGOCAP_BUILD_LIBRARY "Build libegocap.so library for customer SDK" OFF)

if(EGOCAP_BUILD_LIBRARY)
    # Build shared library for customer SDK
    add_library(egocap SHARED
        ${CMAKE_CURRENT_SOURCE_DIR}/src/egocap_api.cpp
    )
    
    target_link_libraries(egocap
        PRIVATE
            ${LIB_DIR}/libseeker.so   # full path
            usb-1.0                   # system libusb-1.0
    )
    
    # Set library version
    set_target_properties(egocap PROPERTIES
        VERSION 1.0.0
        SOVERSION 1
        BUILD_RPATH "\$ORIGIN"
        INSTALL_RPATH "\$ORIGIN"
    )
    
    # Install library
    install(TARGETS egocap
        LIBRARY DESTINATION lib
        COMPONENT SDK
    )
    
    # Install API header
    install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/include/egocap_api.hpp
        DESTINATION include/egocap
        COMPONENT SDK
    )
else()
    # Build executable (default)
    add_executable(egocap
        ${CMAKE_CURRENT_SOURCE_DIR}/src/egocap.cpp
    )

    target_link_libraries(egocap
        PRIVATE
            ${LIB_DIR}/libseeker.so   # full path
            usb-1.0                   # system libusb-1.0
    )

    # Make the binary search for shared libs in its own directory at runtime
    set_target_properties(egocap PROPERTIES
        BUILD_RPATH "\$ORIGIN"
        INSTALL_RPATH "\$ORIGIN"
    )
endif()

# Strip symbols for release builds (after target is created)
if(EGOCAP_STRIP_BINARY AND CMAKE_BUILD_TYPE STREQUAL "Release")
    if(CMAKE_STRIP)
        add_custom_command(TARGET egocap POST_BUILD
            COMMAND ${CMAKE_STRIP} $<TARGET_FILE:egocap>
            COMMENT "Stripping symbols from egocap"
        )
    endif()
endif()

# Install rules for release packaging (executable)
if(NOT EGOCAP_BUILD_LIBRARY)
    install(TARGETS egocap
        RUNTIME DESTINATION bin
        COMPONENT Runtime
    )
endif()

# Install libseeker.so alongside the binary
install(FILES ${LIB_DIR}/libseeker.so
  DESTINATION bin
  COMPONENT Runtime
)

# Install parse_databag.py script
install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/parse_databag.py
  DESTINATION bin
  PERMISSIONS OWNER_READ OWNER_WRITE OWNER_EXECUTE GROUP_READ GROUP_EXECUTE WORLD_READ WORLD_EXECUTE
  COMPONENT Runtime
)

# Install README for end users
install(FILES ${CMAKE_CURRENT_SOURCE_DIR}/README.md
  DESTINATION share/egocap
  RENAME README.txt
  COMPONENT Runtime
)
