#!/bin/bash
# Package release executable for customers
# Creates standalone egocap binary with dependencies

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_NAME="egocap"
VERSION="${1:-1.0.0}"
ARCH="${2:-$(uname -m)}"

# Determine architecture
if [[ "$ARCH" == "x86_64" ]] || [[ "$ARCH" == "amd64" ]]; then
    ARCH_DIR="x86"
    ARCH_NAME="x86_64"
elif [[ "$ARCH" == "aarch64" ]] || [[ "$ARCH" == "arm64" ]]; then
    ARCH_DIR="arm64"
    ARCH_NAME="aarch64"
else
    echo "Error: Unsupported architecture: $ARCH"
    echo "Supported: x86_64, aarch64"
    exit 1
fi

echo "========================================="
echo "Packaging $PROJECT_NAME v$VERSION for $ARCH_NAME"
echo "========================================="

# Build directory
BUILD_DIR="$SCRIPT_DIR/build_release"
PACKAGE_DIR="$SCRIPT_DIR/release"
PACKAGE_NAME="${PROJECT_NAME}-${VERSION}-${ARCH_NAME}"

# Clean previous builds
echo "Cleaning previous builds..."
rm -rf "$BUILD_DIR" "$PACKAGE_DIR"

# Create build directory
mkdir -p "$BUILD_DIR"

# Configure and build
echo "Configuring CMake..."
cd "$BUILD_DIR"
cmake "$SCRIPT_DIR" \
    -DCMAKE_BUILD_TYPE=Release \
    -DEGOCAP_BUILD_LIBRARY=OFF \
    -DEGOCAP_STRIP_BINARY=ON \
    -DCMAKE_INSTALL_PREFIX="$PACKAGE_DIR/$PACKAGE_NAME"

echo "Building..."
cmake --build . -j$(nproc)

echo "Installing to package directory..."
cmake --install .

# Create package structure
cd "$PACKAGE_DIR/$PACKAGE_NAME"

# Hide libseeker.so by renaming it to libegocap_dep.so
# This is done ONLY in packaging, not in CMake (CMake stays clean)
if [ -f "bin/libseeker.so" ]; then
    # Rename the installed libseeker.so
    mv bin/libseeker.so bin/libegocap_dep.so
    echo "Renamed libseeker.so to libegocap_dep.so"
    
    # Use patchelf to rename the dependency in egocap binary
    if command -v patchelf >/dev/null 2>&1; then
        echo "Renaming dependency in egocap binary using patchelf..."
        patchelf --replace-needed libseeker.so libegocap_dep.so bin/egocap
        echo "✓ Dependency renamed successfully"
        
        # Verify it worked
        if ldd bin/egocap 2>/dev/null | grep -q "libegocap_dep"; then
            echo "✓ Verified: egocap binary now references libegocap_dep.so"
        else
            echo "Warning: Verification failed, but continuing..."
        fi
    else
        echo "Error: patchelf not found!"
        echo "Install it: sudo apt install patchelf"
        echo "Cannot hide libseeker.so without patchelf"
        exit 1
    fi
elif [ -f "$SCRIPT_DIR/libs/$ARCH_DIR/libseeker.so" ]; then
    # If not installed by CMake, copy it directly
    cp "$SCRIPT_DIR/libs/$ARCH_DIR/libseeker.so" bin/libegocap_dep.so
    echo "Copied libseeker.so as libegocap_dep.so"
    
    if command -v patchelf >/dev/null 2>&1; then
        patchelf --replace-needed libseeker.so libegocap_dep.so bin/egocap
        echo "✓ Dependency renamed successfully"
    fi
else
    echo "Warning: libseeker.so not found"
fi

# Verify binary dependencies
echo ""
echo "Verifying binary dependencies..."
if command -v ldd >/dev/null 2>&1; then
    echo "Dependencies:"
    ldd bin/egocap 2>&1 || echo "Static executable (no dynamic dependencies)"
fi

# Create installation script
cat > install.sh << 'INSTALL_EOF'
#!/bin/bash
# Installation script for egocap

set -e

INSTALL_DIR="${1:-/opt/egocap}"
BIN_DIR="/usr/local/bin"

echo "Installing egocap to $INSTALL_DIR..."

# Create installation directory
sudo mkdir -p "$INSTALL_DIR/bin"

# Copy files
sudo cp -r bin/* "$INSTALL_DIR/bin/"

# Create symlink
sudo ln -sf "$INSTALL_DIR/bin/egocap" "$BIN_DIR/egocap"
sudo ln -sf "$INSTALL_DIR/bin/parse_databag.py" "$BIN_DIR/parse_databag.py"

# Check for libusb-1.0
if ! ldconfig -p | grep -q libusb-1.0; then
    echo ""
    echo "WARNING: libusb-1.0 not found in system library path."
    echo "Please install it with:"
    echo "  Ubuntu/Debian: sudo apt install libusb-1.0-0"
    echo "  CentOS/RHEL:   sudo yum install libusb"
    echo ""
fi

echo "Installation complete!"
echo "Run 'egocap --help' to get started."
INSTALL_EOF

chmod +x install.sh

# Create README for package
cat > README.txt << README_EOF
========================================
egocap v${VERSION} - Release Package
Architecture: ${ARCH_NAME}
========================================

INSTALLATION:
-------------
1. Install system dependency (if not already installed):
   Ubuntu/Debian: sudo apt install libusb-1.0-0
   CentOS/RHEL:   sudo yum install libusb

2. Run the installation script:
   ./install.sh [install_directory]
   
   Default install directory: /opt/egocap

3. Or manually copy files:
   - Copy bin/egocap to your desired location
   - Copy bin/libegocap_dep.so to the same directory or system library path
   - Copy bin/parse_databag.py to your desired location

USAGE:
------
egocap [output_directory]

See share/egocap/README.txt for detailed usage instructions.

FILES:
------
- bin/egocap          : Main application binary
- bin/libegocap_dep.so: Internal dependency library
- bin/parse_databag.py : Python script for parsing recordings
- share/egocap/README.txt: Detailed documentation

DEPENDENCIES:
-------------
- libusb-1.0 (system library, install via package manager)
- Python 3 (for parse_databag.py, optional)

LICENSE:
--------
This is proprietary software. All rights reserved.
README_EOF

# Create tarball
cd "$PACKAGE_DIR"
echo ""
echo "Creating tarball..."
tar -czf "${PACKAGE_NAME}.tar.gz" "$PACKAGE_NAME"

# Create checksums
echo "Generating checksums..."
sha256sum "${PACKAGE_NAME}.tar.gz" > "${PACKAGE_NAME}.tar.gz.sha256"
md5sum "${PACKAGE_NAME}.tar.gz" > "${PACKAGE_NAME}.tar.gz.md5" 2>/dev/null || true

echo ""
echo "========================================="
echo "Release package created successfully!"
echo "========================================="
echo "Location: $PACKAGE_DIR/${PACKAGE_NAME}.tar.gz"
echo "Size: $(du -h "$PACKAGE_DIR/${PACKAGE_NAME}.tar.gz" | cut -f1)"
echo ""
echo "Package contents:"
ls -lh "$PACKAGE_DIR/${PACKAGE_NAME}/"
echo ""
echo "To distribute:"
echo "  scp $PACKAGE_DIR/${PACKAGE_NAME}.tar.gz user@host:/path/"
echo ""

