// Example customer driver using egocap library
// Customers compile this on their platform and link with libegocap.so

#include "egocap/egocap_api.hpp"
#include <iostream>
#include <csignal>
#include <atomic>
#include <thread>
#include <chrono>

static std::atomic<bool> g_running{true};
static egocap::EgocapHandle* g_handle = nullptr;

void signal_handler(int) {
    g_running = false;
    // Also stop the library immediately when signal is received
    if (g_handle && egocap::egocap_is_running(g_handle)) {
        egocap::egocap_stop(g_handle);
    }
}

// IMU data callback
void on_imu_data(const egocap::ImuData* data, void* user_data) {
    // Process IMU data here
    // This runs in the library's callback thread
    std::cout << "IMU: ts=" << data->device_timestamp_ns 
              << " gyro=(" << data->gyro_x << "," << data->gyro_y << "," << data->gyro_z << ")"
              << " acc=(" << data->acc_x << "," << data->acc_y << "," << data->acc_z << ")\n";
}

// Image data callback
void on_image_data(const egocap::ImageData* data, void* user_data) {
    // Process image data here
    // This runs in the library's callback thread
    std::cout << "Image: ts=" << data->device_timestamp_ns 
              << " size=" << data->jpeg_size << " bytes\n";
}

int main(int argc, char* argv[]) {
    // Setup signal handlers
    std::signal(SIGINT, signal_handler);
    std::signal(SIGTERM, signal_handler);

    // Get output directory from command line (optional)
    const char* output_dir = (argc > 1) ? argv[1] : nullptr;

    // Create egocap instance
    egocap::EgocapHandle* handle = egocap::egocap_create(output_dir);
    if (!handle) {
        std::cerr << "Failed to create egocap instance\n";
        return 1;
    }
    g_handle = handle;  // Store for signal handler

    // Set callbacks
    egocap::egocap_set_imu_callback(handle, on_imu_data, nullptr);
    egocap::egocap_set_image_callback(handle, on_image_data, nullptr);

    // Start recording
    std::cout << "Starting egocap...\n";
    int ret = egocap::egocap_start(handle);
    if (ret != 0) {
        std::cerr << "Failed to start: " << egocap::egocap_get_error(handle) << "\n";
        egocap::egocap_destroy(handle);
        return 1;
    }

    std::cout << "Recording started. Press Ctrl+C to stop.\n";

    // Main loop - wait for stop signal
    while (g_running && egocap::egocap_is_running(handle)) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    // Stop and cleanup (also called from signal handler, but safe to call multiple times)
    if (egocap::egocap_is_running(handle)) {
        std::cout << "Stopping...\n";
        egocap::egocap_stop(handle);
    }
    egocap::egocap_destroy(handle);

    std::cout << "Done.\n";
    return 0;
}

