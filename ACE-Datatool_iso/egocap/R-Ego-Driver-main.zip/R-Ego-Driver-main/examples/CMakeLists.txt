# CMakeLists.txt for customer driver example
# Customers use this to build their driver

cmake_minimum_required(VERSION 3.5)
project(customer_driver)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Find egocap library
# Assumes libegocap.so is in ../lib or system path
# Can be overridden with -DEGOCAP_LIB_DIR=/path/to/lib
if(DEFINED EGOCAP_LIB_DIR)
    set(EGOCAP_LIB "${EGOCAP_LIB_DIR}/libegocap.so")
    message(STATUS "Using egocap library: ${EGOCAP_LIB}")
else()
    find_library(EGOCAP_LIB
        NAMES egocap
        PATHS 
            ${CMAKE_CURRENT_SOURCE_DIR}/../lib
            ${CMAKE_CURRENT_SOURCE_DIR}/../../lib
            /usr/local/lib
            /opt/egocap/lib
        REQUIRED
    )
endif()

# Include directory
# Can be overridden with -DEGOCAP_INCLUDE_DIR=/path/to/include/egocap
# The header is at include/egocap/egocap_api.hpp, so we add the parent directory
if(DEFINED EGOCAP_INCLUDE_DIR)
    # EGOCAP_INCLUDE_DIR points to the egocap subdirectory
    get_filename_component(EGOCAP_INCLUDE_PARENT "${EGOCAP_INCLUDE_DIR}" DIRECTORY)
    include_directories(${EGOCAP_INCLUDE_PARENT})
    message(STATUS "Using egocap include directory: ${EGOCAP_INCLUDE_PARENT}")
else()
    include_directories(
        ${CMAKE_CURRENT_SOURCE_DIR}/../include
        /usr/local/include
        /opt/egocap/include
    )
endif()

# Build customer driver
add_executable(customer_driver customer_driver.cpp)

# Link with egocap library
target_link_libraries(customer_driver
    PRIVATE
        ${EGOCAP_LIB}
)

# Set RPATH so binary can find libegocap.so
set_target_properties(customer_driver PROPERTIES
    BUILD_RPATH "\$ORIGIN/../lib"
    INSTALL_RPATH "\$ORIGIN/../lib"
)

